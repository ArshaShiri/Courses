import java.util.ArrayList;
import java.util.Arrays;

public class FastCollinearPoints {

    // finds all line segments containing 4 or more points
    public FastCollinearPoints(Point[] points) {

        if (points == null) {
            throw new IllegalArgumentException("Input cannot be null!");
        }
        int counter = 1;
        for (Point point : points) {
            if (point == null) throw new IllegalArgumentException("A null point cannot be accepted!");
            //System.out.println("Point point" + counter++ + " = new Point" + point + ";");
        }
        Point[] pointsCopy = points.clone();
        Arrays.sort(pointsCopy);
        checkForDuplicatePoints_(pointsCopy);
        int size = pointsCopy.length;

        for (int index = 0; index < size; ++index) {
            int sizeOfCopiedArray = size - index;
            Point[] pointsSubarray = new Point[sizeOfCopiedArray];

            for (int indexForCopy = 0; indexForCopy < sizeOfCopiedArray; ++indexForCopy) {
                pointsSubarray[indexForCopy] = pointsCopy[index + indexForCopy];
            }

            Point origin = pointsSubarray[0];
            Arrays.sort(pointsSubarray, origin.slopeOrder());
            int numberOfCollinearPoints = 2;

            for (int index2 = 1; index2 < pointsSubarray.length - 1; ++index2) {
                boolean slopesAreEqual = origin.slopeTo(pointsSubarray[index2]) == origin.slopeTo(pointsSubarray[index2 + 1]);
                if (slopesAreEqual) {
                    numberOfCollinearPoints++;
                    if ((index2 == pointsSubarray.length - 2) && (numberOfCollinearPoints > 3)) {
                        LineSegment lineSegment = new LineSegment(origin, pointsSubarray[index2 + 1]);
                        lineSegments_.add(lineSegment);
                        numberOfCollinearPoints = 2;
                        continue;
                    }
                }
                if (!slopesAreEqual) {
                    if (numberOfCollinearPoints > 3) {
                        LineSegment lineSegment = new LineSegment(origin, pointsSubarray[index2]);
                        lineSegments_.add(lineSegment);
                    }
                    numberOfCollinearPoints = 2;
                }
            }
        }
    }

    // the number of line segments
    public int numberOfSegments() {
        return lineSegments_.size();
    }

    // the line segments
    public LineSegment[] segments() {
        return lineSegments_.toArray(new LineSegment[this.numberOfSegments()]);
    }

    // Private methods
    private void checkForDuplicatePoints_(Point[] points) {
        for (int index = 0; index < points.length - 1; ++index) {
            if (points[index].compareTo(points[index + 1]) == 0) {
                throw new IllegalArgumentException("Array has duplicate points!");
            }
        }
    }

    public static void main(String[] args) {
        Point point1 = new Point(26000, 27000);
        Point point2 = new Point(24000, 23000);
        Point point3 = new Point(18000, 23000);
        Point point4 = new Point(22000, 9000);
        Point point5 = new Point(25000, 25000);
        Point point6 = new Point(1000, 2000);
        Point point7 = new Point(12000, 10000);
        Point point8 = new Point(22000, 17000);
        Point point9 = new Point(25000, 1000);
        Point point10 = new Point(15000, 1000);
        Point point11 = new Point(19000, 28000);
        Point point12 = new Point(12000, 3000);
        Point point13 = new Point(4000, 15000);
        Point point14 = new Point(2000, 7000);
        Point point15 = new Point(18000, 27000);
        Point point16 = new Point(9000, 26000);
        Point point17 = new Point(11000, 26000);
        Point point18 = new Point(6000, 16000);
        Point point19 = new Point(18000, 26000);
        Point point20 = new Point(24000, 30000);
        Point point21 = new Point(10000, 25000);
        Point point22 = new Point(7000, 10000);
        Point point23 = new Point(19000, 24000);
        Point point24 = new Point(6000, 0);
        Point point25 = new Point(26000, 15000);
        Point point26 = new Point(1000, 23000);
        Point point27 = new Point(23000, 29000);
        Point point28 = new Point(15000, 7000);
        Point point29 = new Point(15000, 19000);
        Point point30 = new Point(17000, 31000);
        Point point31 = new Point(6000, 2000);
        Point point32 = new Point(17000, 16000);
        Point point33 = new Point(1000, 26000);
        Point point34 = new Point(11000, 19000);
        Point point35 = new Point(25000, 0);
        Point point36 = new Point(17000, 30000);
        Point point37 = new Point(16000, 22000);
        Point point38 = new Point(18000, 13000);
        Point point39 = new Point(3000, 23000);
        Point point40 = new Point(10000, 13000);
        Point point41 = new Point(1000, 9000);
        Point point42 = new Point(11000, 21000);
        Point point43 = new Point(29000, 19000);
        Point point44 = new Point(9000, 29000);
        Point point45 = new Point(30000, 3000);
        Point point46 = new Point(9000, 1000);
        Point point47 = new Point(5000, 29000);
        Point point48 = new Point(26000, 6000);
        Point point49 = new Point(14000, 14000);
        Point point50 = new Point(26000, 26000);

        Point[] points = {point1, point2, point3, point4, point5, point6, point7, point8, point9, point10,
                point11, point12, point13, point14, point15, point16, point17, point18, point19, point20,
                point21, point22, point23, point24, point25, point26, point27, point28, point29, point30,
                point31, point32, point33, point34, point35, point36, point37, point38, point39, point40,
                point41, point42, point43, point44, point45, point46, point47, point48, point49, point50};

        FastCollinearPoints fastCollinearPoints = new FastCollinearPoints(points);
        System.out.println(fastCollinearPoints.numberOfSegments());
        LineSegment[] segments = fastCollinearPoints.segments();

        for (LineSegment segment : segments) {
            System.out.println(segment.toString());
        }
    }

    // Private attributes
    private ArrayList<LineSegment> lineSegments_ = new ArrayList<LineSegment>();
}
