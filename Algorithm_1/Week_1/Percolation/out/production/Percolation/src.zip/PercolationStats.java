/*
To perform a series of computational experiments, create a data type PercolationStats with the following API.
Throw an IllegalArgumentException in the constructor if either n ≤ 0 or trials ≤ 0.

Also, include a main() method that takes two command-line arguments n and T, performs T independent computational
experiments (discussed above) on an n-by-n grid, and prints the sample mean, sample standard deviation, and the 95%
confidence interval for the percolation threshold. Use StdRandom to generate random numbers; use StdStats to compute the
sample mean and sample standard deviation.
*/

import edu.princeton.cs.algs4.StdRandom;
import edu.princeton.cs.algs4.StdStats;

public class PercolationStats {
    // Private attributes
    private double[] results;
    private double mean;
    private double var;

    // Private methods
    private int getNumberOfOpenSitesForPercolation(int n) {
        int numberOfOpenSiteForPercolation = 0;
        Percolation percolation = new Percolation(n);

        while (!percolation.percolates()) {
            int row = StdRandom.uniform(n) + 1;
            int col = StdRandom.uniform(n) + 1;
            //System.out.println(row + ", " + col);
            if (percolation.isOpen(row, col)) {
                continue;
            }
            percolation.open(row, col);
            numberOfOpenSiteForPercolation++;
        }
        return numberOfOpenSiteForPercolation;
    }

    // Public methods
    // perform independent trials on an n-by-n grid
    public PercolationStats(int n, int trials) {
        if (n <= 0 || trials <= 0) {
            throw new IllegalArgumentException("Invalid trials or n " + n + ",  " + trials);
        }

        int gridSize = n * n;
        results = new double[trials];
        for (int i = 0; i < trials; ++i) {
            results[i] = (double) getNumberOfOpenSitesForPercolation(n) / gridSize;
        }
        mean = StdStats.mean(results);
        var = StdStats.stddev(results);
    }


    // sample mean of percolation threshold
    public double mean() {
        return mean;
    }

    // sample standard deviation of percolation threshold
    public double stddev() {
        return var;
    }

    // low endpoint of 95% confidence interval
    public double confidenceLo() {
        return mean - (1.96 * var / Math.sqrt(results.length));
    }

    // high endpoint of 95% confidence interval
    public double confidenceHi() {
        return mean + (1.96 * var / Math.sqrt(results.length));
    }

    // test client (see below)
    public static void main(String[] args) {
    }

}
