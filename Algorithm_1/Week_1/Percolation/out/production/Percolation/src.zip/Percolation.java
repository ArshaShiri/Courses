/*
Corner cases.  By convention, the row and column indices are integers between 1 and n, where (1, 1) is the upper-left
site: Throw an IllegalArgumentException if any argument to open(), isOpen(), or isFull() is outside its prescribed range.
Throw an IllegalArgumentException in the constructor if n ≤ 0.
*/

/*
Performance requirements.  The constructor should take time proportional to n2; all methods should take constant time
plus a constant number of calls to the union–find methods union(), find(), connected(), and count().
*/

import edu.princeton.cs.algs4.StdOut;
import edu.princeton.cs.algs4.WeightedQuickUnionUF;

public class Percolation {
    // Private attributes
    private WeightedQuickUnionUF fullUnionFind;
    private WeightedQuickUnionUF gridUnionFind;
    private boolean[] isOpen; // Grid size is n * n
    private int sizeOfRowsAndColumns;
    private int gridSize;
    private int numberOfOpenSitesExcludingVirtualSites;

    // Private methods
    private int getArrayIndexFromRowAndColumn(int row, int col) {
        // A site located in row i and column j is equivalent to a component located in the position
        // (row - 1) * sizeOfRowsAndColumns + col
        validateGridArrayIndex(row, col);
        int index = (row - 1) * sizeOfRowsAndColumns + col;
        return index;
    }

    private void validateGridArrayIndex(int row, int col) {
        if (row < 1 || row > sizeOfRowsAndColumns) {
            throw new IllegalArgumentException("Row index " + row + " is not between 1 and " + (sizeOfRowsAndColumns));
        }
        if (col < 1 || col > sizeOfRowsAndColumns) {
            throw new IllegalArgumentException("Col index " + col + " is not between 1 and " + (sizeOfRowsAndColumns));
        }
    }

    private void tryUnion(int arrayIndex1, int row, int col) {
        if (isOpen(row, col)) {
            int arrayIndex2 = getArrayIndexFromRowAndColumn(row, col);
            if (!isOpen[arrayIndex2]) {
                numberOfOpenSitesExcludingVirtualSites++;
            }
            gridUnionFind.union(arrayIndex1, arrayIndex2);
            fullUnionFind.union(arrayIndex1, arrayIndex2);
        }
    }

    private void connectOpenNeighbours(int row, int col, int arrayIndex) {
        boolean isSiteOnFirstRow = row == 1;
        boolean isSiteOnLastRow = row == sizeOfRowsAndColumns;
        if (isSiteOnFirstRow) {
            isOpen[0] = true;
            fullUnionFind.union(arrayIndex, 0);
            gridUnionFind.union(arrayIndex, 0);
            tryUnion(arrayIndex, row + 1, col);
        }
        if (isSiteOnLastRow) {
            isOpen[gridSize + 1] = true;
            gridUnionFind.union(arrayIndex, gridSize + 1);
            tryUnion(arrayIndex, row - 1, col);
        }

        boolean siteIsNotOnFirstOrLastRow = !(isSiteOnFirstRow || isSiteOnLastRow);
        if (siteIsNotOnFirstOrLastRow) {
            tryUnion(arrayIndex, row + 1, col);
            tryUnion(arrayIndex, row - 1, col);
        }

        if (col == 1) {
            tryUnion(arrayIndex, row, col + 1);
        } else if (col == sizeOfRowsAndColumns) {
            tryUnion(arrayIndex, row, col - 1);
        } else {
            tryUnion(arrayIndex, row, col + 1);
            tryUnion(arrayIndex, row, col - 1);
        }
    }

    // Public methods
    // creates n-by-n grid, with all sites initially blocked
    public Percolation(int n) {
        if (n <= 0) {
            throw new IllegalArgumentException("Grid size " + n + " is not valid ");
        }
        gridSize = n * n;
        sizeOfRowsAndColumns = n;
        numberOfOpenSitesExcludingVirtualSites = 0;
        isOpen = new boolean[gridSize + 2];

        // All sites initially blocked.
        for (int i = 0; i < gridSize; ++i) {
            isOpen[i] = false;
        }

        // Take the two additional virtual sites into account.
        gridUnionFind = new WeightedQuickUnionUF(gridSize + 2);

        // Another union find object to avoid back wash problem.
        // Only the virtual node at the top is needed to check if a path is open.
        fullUnionFind = new WeightedQuickUnionUF(gridSize + 1);
    }

    // opens the site (row, col) if it is not open already
    public void open(int row, int col) {
        int arrayIndex = getArrayIndexFromRowAndColumn(row, col);
        if (isOpen[arrayIndex]) {
            return;
        }
        numberOfOpenSitesExcludingVirtualSites++;
        isOpen[arrayIndex] = true;
        connectOpenNeighbours(row, col, arrayIndex);
    }

    // Is the site (row, col) open?
    public boolean isOpen(int row, int col) {
        int arrayIndex = getArrayIndexFromRowAndColumn(row, col);
        return isOpen[arrayIndex];
    }

    // is the site (row, col) full?
    // A full site is an open site that can be connected to an open site in the top row via a chain of neighboring
    // (left, right, up, down) open sites. We say the system percolates if there is a full site in the bottom row.
    public boolean isFull(int row, int col) {
        int index = getArrayIndexFromRowAndColumn(row, col);
        return fullUnionFind.connected(0, index);
    }

    // returns the number of open sites
    public int numberOfOpenSites() {
        return numberOfOpenSitesExcludingVirtualSites;
    }

    // does the system percolate?
    public boolean percolates() {
        return gridUnionFind.connected(0, gridSize + 1);
    }

    // test client (optional)
    public static void main(String[] args) {
        Percolation percolation = new Percolation(5);
        percolation.open(1, 1);
        percolation.open(1, 2);
        percolation.open(2, 2);
        percolation.open(2, 3);
        percolation.open(3, 3);
        percolation.open(3, 2);
        percolation.open(3, 1);
        percolation.open(4, 1);
        percolation.open(4, 2);
        percolation.open(5, 2);
        percolation.open(5, 4);
        StdOut.println(percolation.percolates());
        StdOut.println(percolation.numberOfOpenSites() == 11);
        // Must be false
        StdOut.println(percolation.isFull(5, 4));
        // Must be true
        StdOut.println(percolation.isFull(5, 2));
    }
}
