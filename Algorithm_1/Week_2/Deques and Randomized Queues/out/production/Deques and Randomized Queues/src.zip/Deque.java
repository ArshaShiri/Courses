import java.util.Iterator;

public class Deque<Item> implements Iterable<Item> {

    // construct an empty deque
    public Deque() {
    }

    // is the deque empty?
    public boolean isEmpty() {
        return size == 0;
    }

    // return the number of items on the deque
    public int size() {
        return size;
        //
    }

    // add the item to the front
    public void addFirst(Item item) {
        if (item == null) {
            throw new IllegalArgumentException("Cannot add a null object to the beginning of the deque!");
        }

        Node oldFirst = first;
        first = new Node();
        first.item = item;

        if (size == 0) {
            last = first;
        } else {
            first.previous = oldFirst;
            oldFirst.next = first;
        }
        size++;
    }

    // add the item to the back
    public void addLast(Item item) {
        if (item == null) {
            throw new IllegalArgumentException("Cannot add a null object to the end of the deque!");
        }

        Node oldLast = last;
        last = new Node();
        last.item = item;

        if (size == 0) {
            first = last;
        } else {
            last.next = oldLast;
            oldLast.previous = last;
        }
        size++;
    }

    // remove and return the item from the front
    public Item removeFirst() {
        if (size == 0) {
            throw new java.util.NoSuchElementException("Cannot remove the first node from an empty deque!");
        }

        Item itemInFirst = first.item;

        // Set the next method of the previous node to point to null
        first = first.previous;
        if (first != null) {
            first.next = null;
        } else {
            last = null;
        }
        size--;
        return itemInFirst;
    }

    // remove and return the item from the back
    public Item removeLast() {
        if (size == 0) {
            throw new java.util.NoSuchElementException("Cannot remove the last node from an empty deque!");
        }

        Item itemInLast = last.item;

        // Set the previous method of the next node to point to null
        last = last.next;
        if (last != null) {
            last.previous = null;
        } else {
            first = null;
        }
        size--;
        return itemInLast;
    }

    // return an iterator over items in order from front to back
    public Iterator<Item> iterator() {
        return new DequeIterator();
    }

    // unit testing (required)
    public static void main(String[] args) {
/*        Deque<Integer> deque = new Deque<Integer>();
        deque.addLast(1);
        deque.addFirst(2);
        deque.removeLast();
        deque.removeLast();
        Iterator<Integer> iterator = deque.iterator();
        deque.size();
        Deque<Integer> testDeque = new Deque<>();
        testDeque.addFirst(10);
        System.out.println(testDeque.isEmpty());
        System.out.println(testDeque.removeLast());
        System.out.println(testDeque.isEmpty());

        for (int i = 0; i < 10; i++) {
            System.out.println("Adding " + i + " to the first");
            testDeque.addFirst(i);
            System.out.println("Adding " + 2 * i + " to the last");
            testDeque.addLast(2 * i);
        }

        // Expect 20
        System.out.println(testDeque.size());

        // Test the iterator
        Iterator<Integer> iterator = testDeque.iterator();
        while (iterator.hasNext()) {
            int i = iterator.next();
            System.out.println("Iterator: " + i);
        }*/
    }


    // Private classes
    private class Node {
        Item item;
        Node next = null;
        Node previous = null;
    }

    private class DequeIterator implements Iterator<Item> {

        public boolean hasNext() {
            return current != null;
        }

        public void remove() {
            throw new UnsupportedOperationException();
        }

        public Item next() {
            if (!hasNext()) {
                throw new java.util.NoSuchElementException("Next item does not exist in the iterator! ");
            }

            Item item = current.item;
            current = current.previous;
            return item;
        }

        private Node current = first;
    }

    // Private attributes
    private Node first = null;
    private Node last = null;
    private int size = 0;
}
