import java.util.Arrays;
import java.util.LinkedList;

public class Board {
    // Private attributes
    private int rowOfZero_;
    private int colOfZero_;
    private final int n_;
    private final int[][] tiles_;
    //private final int[][] finalSolution_;
    // 1 2 3
    // 4 5 6
    // 7 8 0

    // Private methods
    private int getAbsoluteValue_(int val) {
        if (val >= 0) return val;
        else return -val;
    }

    private static int[][] deepCopy_(int[][] original) {
        if (original == null) {
            return null;
        }

        final int[][] result = new int[original.length][];
        for (int i = 0; i < original.length; i++) {
            result[i] = Arrays.copyOf(original[i], original[i].length);
        }

        return result;
    }

    private int[][] getNewBoardWithSwapElements(
            int[][] oldTIle, int oldRow, int oldColumn, int newRow, int newColumn) {

        int[][] newTiles = deepCopy_(oldTIle);
        int temp = newTiles[oldRow][oldColumn];
        newTiles[oldRow][oldColumn] = newTiles[newRow][newColumn];
        newTiles[newRow][newColumn] = temp;
        return newTiles;
    }

    private int getDistanceToFinalLocation_(int tile, int currentRow, int currentCol) {
        if (tile == 0) return 0;

        // According to the final solution, the row and column of each entry can be calculated.
        int rowInFinalSolution = (tile - 1) / n_;
        int colInFinalSolution = (tile - 1) - rowInFinalSolution * n_;
/*        int remainder = tile % n_;
        int rowInFinalSolution = 0;
        int colInFinalSolution = 0;

        if (remainder == 0) {
            rowInFinalSolution = tile / n_ - 1;
            colInFinalSolution = 2;
        } else {
            rowInFinalSolution = tile / n_;
            colInFinalSolution = remainder - 1;
        }*/

        return getAbsoluteValue_(rowInFinalSolution - currentRow) +
                getAbsoluteValue_(colInFinalSolution - currentCol);
    }

    // create a board from an n-by-n array of tiles,
    // where tiles[row][col] = tile at (row, col)
    public Board(int[][] tiles) {

        if (tiles == null) {
            throw new IllegalArgumentException("Tiles are null");
        }

        n_ = tiles[0].length;
        tiles_ = deepCopy_(tiles);

        // Get the row and the col for the element zero (empty space in the board)
        for (int col = 0; col < this.n_; col++) {
            for (int row = 0; row < n_; row++) {
                if (tiles_[row][col] == 0) {
                    rowOfZero_ = row;
                    colOfZero_ = col;
                    break;
                }
            }
        }

/*        int counter = 1;
        finalSolution_ = new int[n_][n_];
        for (int row = 0; row < n_; row++) {
            for (int col = 0; col < n_; col++) {
                finalSolution_[row][col] = counter++;
            }
        }
        finalSolution_[n_ - 1][n_ - 1] = 0;*/
    }


    // string representation of this board
    public String toString() {
        StringBuilder board = new StringBuilder();
        board.append(n_ + "\n");

        for (int i = 0; i < n_; i++) {
            for (int j = 0; j < n_; j++) {
                board.append(String.format("%2d ", tiles_[i][j]));
            }
            board.append("\n");
        }
        return board.toString();
    }

    // board dimension n
    public int dimension() {
        return n_;
    }

    // number of tiles out of place
    public int hamming() {
        int numberOfTilesOutOfPlace = 0;
        for (int row = 0; row < n_; row++) {
            for (int col = 0; col < n_; col++) {
                if (tiles_[row][col] == 0) continue;
                if (tiles_[row][col] != row * n_ + col + 1) numberOfTilesOutOfPlace++;
            }
        }

        return numberOfTilesOutOfPlace;
    }

    // sum of Manhattan distances between tiles and goal
    public int manhattan() {
        int manhattanCoefficient = 0;

        for (int row = 0; row < n_; row++) {
            for (int col = 0; col < n_; col++) {
                manhattanCoefficient += getDistanceToFinalLocation_(tiles_[row][col], row, col);
            }
        }

        return manhattanCoefficient;
    }

    // is this board the goal board?
    public boolean isGoal() {
        return hamming() == 0;
    }

    // does this board equal y?
    public boolean equals(Object y) {
        if (y == this) return true;
        if (y == null) return false;
        if (y.getClass() != this.getClass())
            return false;

        Board that = (Board) y;
        if (this.dimension() != that.dimension()) return false;

        int[][] thisTiles = this.tiles_;
        int[][] thatTiles = that.tiles_;
        for (int col = 0; col < this.n_; col++) {
            for (int row = 0; row < n_; row++) {
                if (thisTiles[row][col] != thatTiles[row][col]) return false;
            }
        }

        return true;
    }

    // all neighboring boards
    public Iterable<Board> neighbors() {
        LinkedList<Board> neighbors = new LinkedList<Board>();

//        int rowOfZero = 0;
//        int colOfZero = 0;

/*        // Get the row and the col for the element zero (empty space in the board)
        for (int col = 0; col < this.n_; col++) {
            for (int row = 0; row < n_; row++) {
                if (tiles_[row][col] == 0) {
                    rowOfZero = row;
                    colOfZero = col;
                    break;
                }
            }
        }*/

        if (rowOfZero_ > 0)
            neighbors.add(new Board(getNewBoardWithSwapElements(tiles_, rowOfZero_, colOfZero_, rowOfZero_ - 1, colOfZero_)));
        if (rowOfZero_ < n_ - 1)
            neighbors.add(new Board(getNewBoardWithSwapElements(tiles_, rowOfZero_, colOfZero_, rowOfZero_ + 1, colOfZero_)));

        if (colOfZero_ > 0)
            neighbors.add(new Board(getNewBoardWithSwapElements(tiles_, rowOfZero_, colOfZero_, rowOfZero_, colOfZero_ - 1)));
        if (colOfZero_ < n_ - 1)
            neighbors.add(new Board(getNewBoardWithSwapElements(tiles_, rowOfZero_, colOfZero_, rowOfZero_, colOfZero_ + 1)));

        return neighbors;
    }

    // a board that is obtained by exchanging any pair of tiles
    public Board twin() {
        for (int row = 0; row < n_; row++) {
            for (int col = 0; col < n_ - 1; col++) {
                if (row != rowOfZero_)
                    return new Board(getNewBoardWithSwapElements(tiles_, row, col, row, col + 1));
            }
        }

        throw new RuntimeException("Cannot acquire the twin board");
/*        while (true) {
            int row1 = StdRandom.uniform(n_);
            int col1 = StdRandom.uniform(n_);
            int row2 = StdRandom.uniform(n_);
            int col2 = StdRandom.uniform(n_);
            if (row1 != row2 || col1 != col2) {
                if (tiles_[row1][col1] == 0 || tiles_[row2][col2] == 0) continue;
                return new Board(getNewBoardWithSwapElements(tiles_, row1, col1, row2, col2));
            }
        }*/
    }

    // unit testing (not graded)
    public static void main(String[] args) {
    }
}
