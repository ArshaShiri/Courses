import edu.princeton.cs.algs4.In;
import edu.princeton.cs.algs4.MinPQ;
import edu.princeton.cs.algs4.Stack;
import edu.princeton.cs.algs4.StdOut;

public class Solver {
    // Private attributes
    private Stack<Board> solutions_ = new Stack<Board>();

    private int numberOfMoves_;
    private boolean isSolvable_;

    // Private methods and classes
    private class SearchNode_ implements Comparable<SearchNode_> {
        private SearchNode_ previousSearchNode_ = null;
        private Board board_;
        private int manhattan_;
        private int numberOfMoves_ = 0;

        SearchNode_(Board board) {
            board_ = board;
            manhattan_ = board.manhattan();
        }

        SearchNode_(Board board, SearchNode_ previousSearchNode) {
            board_ = board;
            previousSearchNode_ = previousSearchNode;
            numberOfMoves_ = previousSearchNode.numberOfMoves_ + 1;
            manhattan_ = board.manhattan();
        }

        public int compareTo(SearchNode_ searchNode) {
            int manhattanPriorityFunctionOfThis = this.manhattan_ + this.numberOfMoves_;
            int manhattanPriorityFunctionOfThat = searchNode.manhattan_ + searchNode.numberOfMoves_;
            return manhattanPriorityFunctionOfThis - manhattanPriorityFunctionOfThat;
        }
    }

    private void updateQueue_(SearchNode_ currentSearchNode, MinPQ<SearchNode_> queue) {
        Board board = currentSearchNode.board_;
        Iterable<Board> neighbors = currentSearchNode.board_.neighbors();
        for (Board neighbor : neighbors) {

            if (currentSearchNode.previousSearchNode_ != null) {
                if (neighbor.equals(currentSearchNode.previousSearchNode_.board_)) continue;
            }
            queue.insert(new SearchNode_(neighbor, currentSearchNode));
        }
    }


    // find a solution to the initial board (using the A* algorithm)
    public Solver(Board initial) {
        if (initial == null) throw new IllegalArgumentException("Null initial board");

        MinPQ<SearchNode_> searchNodes = new MinPQ<SearchNode_>();
        MinPQ<SearchNode_> twinSearchNodes = new MinPQ<SearchNode_>();

        searchNodes.insert(new SearchNode_(initial));
        twinSearchNodes.insert(new SearchNode_(initial.twin()));

        while (true) {
            SearchNode_ currentSearchNode = searchNodes.delMin();
            SearchNode_ currentTwinSearchNode = twinSearchNodes.delMin();
            Board currentBoard = currentSearchNode.board_;
            Board twinBoard = currentTwinSearchNode.board_;
            //solutions_.add(currentBoard);
/*            StdOut.println("Current Board: " + currentBoard.toString());
            StdOut.println("Current Manhattan: " + currentBoard.manhattan());
            StdOut.println("Current Hamming: " + currentBoard.hamming());
            StdOut.println("Current Moves: " + currentSearchNode.numberOfMoves_);*/

            // Check if we have reached the goal
            if (currentBoard.isGoal()) {
                numberOfMoves_ = currentSearchNode.numberOfMoves_;
                while (currentSearchNode != null) {
                    solutions_.push(currentSearchNode.board_);
                    currentSearchNode = currentSearchNode.previousSearchNode_;
                }

                isSolvable_ = true;
                break;
            } else if (twinBoard.isGoal()) {
                numberOfMoves_ = -1;
                isSolvable_ = false;
                break;
            }

            // update the queues
            updateQueue_(currentSearchNode, searchNodes);
            updateQueue_(currentTwinSearchNode, twinSearchNodes);
        }
    }

    // is the initial board solvable? (see below)
    public boolean isSolvable() {
        return isSolvable_;
    }

    // min number of moves to solve initial board
    public int moves() {
        return numberOfMoves_;
    }

    // sequence of boards in a shortest solution
    public Iterable<Board> solution() {
        if (!isSolvable_) return null;
        return solutions_;
    }

    // test client (see below)
    public static void main(String[] args) {
        // create initial board from file
        In in = new In(args[0]);
        int n = in.readInt();
        int[][] tiles = new int[n][n];
        for (int i = 0; i < n; i++)
            for (int j = 0; j < n; j++)
                tiles[i][j] = in.readInt();
        Board initial = new Board(tiles);

        // solve the puzzle
        Solver solver = new Solver(initial);

        // print solution to standard output
        if (!solver.isSolvable())
            StdOut.println("No solution possible");
        else {
            StdOut.println("Minimum number of moves = " + solver.moves());
            for (Board board : solver.solution())
                StdOut.println(board);
        }
    }

}
