public class Dictionary {
    // Dictionary implementation for words with upper case only.
    // Since there are 26 nodes and the upper case characters are
    // between 65 to 90 we need to subtract the ASCII code of each
    // character by 65.
    // *** *** *** *** *** Private Attributes *** *** *** *** *** //

    private static final int R_ = 26;
    private Node_ root_ = new Node_();

    // *** *** *** *** *** Private Classes *** *** *** *** *** //

    private static class Node_ {
        private Integer val;
        private Node_[] next = new Node_[R_];
    }

    // *** *** *** *** *** Private Methods *** *** *** *** *** //

    private void put_(String key, Integer val) {
        root_ = put_(root_, key, val, 0);
    }

    private Node_ put_(Node_ x, String key, Integer val, int d) {
        if (x == null) x = new Node_();
        if (d == key.length()) {
            x.val = val;
            return x;
        }
        char c = key.charAt(d);
        x.next[c - 65] = put_(x.next[c - 65], key, val, d + 1);
        return x;
    }

    private boolean contains_(String key) {
        Integer val = get_(key);
        return val != null;
    }

    private Boolean getPrefix_(String key) {
        return getPrefix_(root_, key, 0) != null;
    }

    private Integer getPrefix_(Node_ x, String key, int d) {
        if (x == null) return null;
        if (d == key.length()) return 1;
        char c = key.charAt(d);
        return getPrefix_(x.next[c - 65], key, d + 1);
    }

    private Integer get_(String key) {
        Node_ x = get_(root_, key, 0);
        if (x == null) return null;
        return x.val;
    }

    private Node_ get_(Node_ x, String key, int d) {
        if (x == null) return null;
        if (d == key.length()) return x;
        char c = key.charAt(d);
        return get_(x.next[c - 65], key, d + 1);
    }

    // *** *** *** *** *** Public Methods *** *** *** *** *** //

    public Dictionary(String[] dictionary) {
        if (dictionary == null) {
            throw new IllegalArgumentException("File is null!");
        }

        int counter = 0;
        for (String word : dictionary) {
            if (word.length() > 2) {
                put_(word, counter);
                counter++;
            }
        }
    }

    public boolean isWordInDictionary(String queryWord) {
        return contains_(queryWord);
    }

    public boolean doesPrefixExist(String prefix) {
        // Only for 3-letter prefix
        return getPrefix_(prefix);
    }
}


//public class Dictionary {
//    // *** *** *** *** *** Private Attributes *** *** *** *** *** //
//
//    private HashSet<String> dictionary_;
//
//    // *** *** *** *** *** Public Methods *** *** *** *** *** //
//
//    public Dictionary(String[] dictionary) {
//        if (dictionary == null) {
//            throw new IllegalArgumentException("File is null!");
//        }
//
//        dictionary_ = new HashSet<>();
//        Collections.addAll(dictionary_, dictionary);
//    }
//
//    public boolean doesPrefixExist(String prefix) {
//        KMP kmp = new KMP(prefix);
//        for (String word : dictionary_) {
//            if (kmp.search(word) != word.length()) return true;
//        }
//        return false;
//    }
//
//    public boolean isWordInDictionary(String queryWord) {
//        return dictionary_.contains(queryWord);
//    }
//}
